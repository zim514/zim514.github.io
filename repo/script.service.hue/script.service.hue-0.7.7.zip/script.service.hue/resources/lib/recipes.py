
#Must be in the same order as labels in setings.xml
HUE_RECIPES = {}
HUE_RECIPES[0] = {"name":"Do nothing", "xy":(0,0)}
HUE_RECIPES[1] = {"name":"Relax", "xy":(0.5016,0.4151)}
HUE_RECIPES[2] = {"name":"Read", "xy":(0.4452,0.4068)}
HUE_RECIPES[3] = {"name":"Concentrate", "xy":(0.3691,0.3719)}
HUE_RECIPES[4] = {"name":"Bright", "xy":(0.4578,0.4099)}
HUE_RECIPES[5] = {"name":"Energize", "xy":(0.3143,0.3301)}
HUE_RECIPES[6] = {"name":"Candelight", "xy":(0.5266,0.4133)}
HUE_RECIPES[7] = {"name":"Incandescent", "xy":(0.4594,0.4104)}
HUE_RECIPES[8] = {"name":"Pumpkin", "xy":(0.6193,0.3625)}

