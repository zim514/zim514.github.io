from threading import Event

CONNECTED = False
AMBI_RUNNING = Event()
